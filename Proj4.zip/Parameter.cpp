//
// Created by dakot on 5/15/2021.
//

#include "Parameter.h"

std::string Parameter::toString() {
    return this->token->getData();
}

Token Parameter::getTokens() {
    return *token;
}
